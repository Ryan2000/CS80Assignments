<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Thanks</title>
</head>
<body>
    <?php
    // Only do anything if a post request was sent to this form handler.
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Get the visitor's information by the "name" attribute of the input
        // element in the user HTML form.
        $Gender = $_POST['Gender'];
        $Race = $_POST['Race'];
        $AgeRange = $_POST['Age_Range'];
        $MaritalStatus = $_POST['Marital_Status'];
        $Education = $_POST['Education'];
        $EmploymentStatus = $_POST['Employment_Status'];
        $HouseholdIncome = $_POST['Household_Income'];
        $PoliticalAffiliation = $_POST['Political_Affiliation'];
        $PoliticalViews = $_POST['Political_Views'];
        $ElectedOfficials = $_POST['Elected_Officials'];
        $Congress = $_POST['Congress'];
        $RacialBias = $_POST['Racial_Bias'];
        $GenderBias = $_POST['Gender_Bias'];
        $Religion = $_POST['Religion'];
        $EconomicIssues = $_POST['Economic_Issues'];
        $EqualRights = $_POST['Equal_Rights'];
        $Candidates = $_POST['Candidates'];
        $PoliticalSystem = $_POST['Political_System'];
        $Vote = $_POST['Vote'];

        // Create a data source name string. This is a connection string to the
        // database from PHP.
        $dsn = 'mysql:host=localhost;dbname=survey_results';
        $username = 'rhoyda';
        $password = '!QAZ2wsx3edc';
        // Get a database handler PHP Data Object (PDO). We use the DSN to
        // connect to the database in this statement. The database handler is
        // an object that will relay actions to the database for us like inserting
        // or retrieving records.
        $dbh = new PDO($dsn, $username, $password);
    
        // Create a basic SQL statement that inserts a row with the name
        // provided by the user form into the visitors table.
        $sql = "INSERT INTO analysis (Gender, Race, Age_Range, Marital_Status, Education, Employment_Status, Household_Income, 
        Political_Affiliation, Political_Views, Elected_Officials, Congress, Racial_Bias, Gender_Bias, Religion, Economic_Issues, Equal_Rights,
        Candidates, Political_System, Vote) VALUES "
        . "('$Gender', '$Race', '$AgeRange', '$MaritalStatus', '$Education', '$EmploymentStatus', '$HouseholdIncome', '$PoliticalAffiliation', '$PoliticalViews',
        '$ElectedOfficials', '$Congress', '$RacialBias', '$GenderBias', '$Religion', '$EconomicIssues', '$EqualRights', '$Candidates', '$PoliticalSystem', '$Vote');";
    
        // The database handler has an exec function returns the number of rows
        // affected by your SQL statement.
        $rowCount = $dbh->exec($sql);
        // If a row was affected by the SQL statement, write a success message.
        if ($rowCount > 0) {
            // Prints the contents of thanks.html to this file. You can think of
            // this like using "echo" on every line of the file specified.
            readfile('thanks.html');
        } else {
            // If no row was affected, write a failure message.
            readfile('error.html');
            echo var_dump($dbh->errorInfo());
        }
    }
    ?>
</body>
</html>